package com.example.hoo.mobilitytest.network

import io.reactivex.Single
import okhttp3.OkHttpClient
import okhttp3.Request

private const val URL = "http://www.gettyimagesgallery.com/collections/archive/slim-aarons.aspx"

val defaultHttpClient: OkHttpClient = OkHttpClient.Builder().build()

fun getStringResponse(): Single<String> {
    return Request.Builder().url(URL).tag(URL).build().run {
        Single.fromCallable {
            defaultHttpClient.newCall(this).execute().body()?.string()
        }
    }
}

fun cancelRequest() {
    defaultHttpClient
            .dispatcher()
            .queuedCalls()
            .find {
                it.request().tag() == URL
            }?.cancel()

    defaultHttpClient
            .dispatcher()
            .runningCalls()
            .find {
                it.request().tag() == URL
            }?.cancel()
}