package com.example.hoo.mobilitytest.base

interface BasePresenter