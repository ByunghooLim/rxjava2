package com.example.hoo.mobilitytest.view.main

import android.os.Bundle
import com.example.hoo.mobilitytest.Extras.SAVED_IMAGE_DATA
import com.example.hoo.mobilitytest.model.ImageData
import com.example.hoo.mobilitytest.network.defaultHttpClient
import com.example.hoo.mobilitytest.view.main.contract.MainContract
import org.junit.Before
import org.junit.Test
import org.mockito.ArgumentMatchers
import org.mockito.Mockito
import org.mockito.Mockito.verify

class MainPresenterImplTest {
    private lateinit var mainPresenterImpl : MainPresenterImpl
    private lateinit var view : MainContract.View

    @Before
    fun setUp() {
        view = Mockito.mock(MainContract.View::class.java)
        mainPresenterImpl = MainPresenterImpl(view)
    }

    @Test
    fun initFromNetwork() {
        mainPresenterImpl.initFromNetwork()

        Thread.sleep(1500)

        verify(view).mainAdapter = ArgumentMatchers.any()
    }

    @Test
    fun initFromSavedInstance() {
        ArrayList<ImageData>().apply {
            add(ImageData("1"))
            add(ImageData("2"))
        }.run {
            val bundle = Bundle()
            bundle.putParcelableArrayList(SAVED_IMAGE_DATA.toString(), this)
            bundle
        }.apply {
            mainPresenterImpl.initFromSavedInstance(this)
        }

        verify(view).mainAdapter = ArgumentMatchers.any()
    }

    @Test
    fun onSaveData() {
        mainPresenterImpl.initFromNetwork()

        Thread.sleep(1500)

        val bundle = Bundle()
        mainPresenterImpl.onSaveData(Bundle())

        assert(bundle.getParcelableArrayList<ImageData>(SAVED_IMAGE_DATA.toString())?.size == 549)
    }

    @Test
    fun cancelNetwork() {
        mainPresenterImpl.cancelNetwork()

        assert(defaultHttpClient
                .dispatcher()
                .queuedCalls().isEmpty())

        assert(defaultHttpClient
                .dispatcher()
                .runningCalls().isEmpty())
    }
}