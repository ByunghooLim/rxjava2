package com.example.hoo.mobilitytest.extensions

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.Point

inline fun <reified T : Activity> Context?.startActivity(options: (Intent) -> Unit) {
    this?.let {
        Intent(this, T::class.java).run {
            options(this)
            startActivity(this)
        }
    }
}

fun Context?.getDisplaySize(): Point {
    return this?.resources?.displayMetrics?.let {
        return Point(it.widthPixels, it.heightPixels)
    } ?: Point()
}