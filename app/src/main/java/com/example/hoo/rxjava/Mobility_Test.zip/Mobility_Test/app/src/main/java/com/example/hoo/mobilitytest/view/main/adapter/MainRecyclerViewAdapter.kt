package com.example.hoo.mobilitytest.view.main.adapter

import android.databinding.DataBindingUtil
import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.ViewGroup
import com.example.hoo.mobility_test.R
import com.example.hoo.mobility_test.databinding.ViewholderImageBinding
import com.example.hoo.mobilitytest.Extras.IMAGE_DATA
import com.example.hoo.mobilitytest.extensions.getDisplaySize
import com.example.hoo.mobilitytest.extensions.startActivity
import com.example.hoo.mobilitytest.extensions.toGlideImg
import com.example.hoo.mobilitytest.model.ImageData
import com.example.hoo.mobilitytest.view.detail.DetailActivity
import com.jakewharton.rxbinding2.view.RxView
import java.util.concurrent.TimeUnit

class MainRecyclerViewAdapter(val dataList: MutableList<ImageData>) : RecyclerView.Adapter<ImageViewHolder>() {
    override fun onBindViewHolder(holder: ImageViewHolder, position: Int) {
        holder setTagData dataList[position]
        holder setImage dataList[position]
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) = ImageViewHolder(DataBindingUtil.inflate(LayoutInflater.from(parent.context), R.layout.viewholder_image, parent, false))
    override fun getItemCount() = dataList.size
}

class ImageViewHolder(private val binding: ViewholderImageBinding) : RecyclerView.ViewHolder(binding.root) {
    init {
        RxView.clicks(binding.root)
                .throttleFirst(2000, TimeUnit.MILLISECONDS)
                .subscribe {
                    //val view = it as View
                    binding.root.context.startActivity<DetailActivity> {
                        it.putExtra(IMAGE_DATA.toString(), binding.root.getTag(R.id.imageData) as ImageData)
                    }
                }

//        io.reactivex.Observable.create<View> { emit ->
//            binding.root.setOnClickListener {
//                emit.onNext(it)
//            }
//            emit.onComplete()
//        }.subscribe {view ->
//            view.context.startActivity<DetailActivity> {
//                it.putExtra(IMAGE_DATA.toString(),view.getTag(R.id.imageData) as ImageData)
//            }
//        }

        //        binding?.root?.setOnClickListener { view ->
//
//        }

        binding.root.let {
            it.layoutParams = it.layoutParams.apply {
                this.height = it.context.getDisplaySize().x / 2
            }
        }
    }

    infix fun setTagData(imageData: ImageData) {
        binding.root.setTag(R.id.imageData, imageData)
    }

    infix fun setImage(imageData: ImageData) {
        binding.image.toGlideImg {
            it.load(imageData.ImageUrl)
        }
    }
}