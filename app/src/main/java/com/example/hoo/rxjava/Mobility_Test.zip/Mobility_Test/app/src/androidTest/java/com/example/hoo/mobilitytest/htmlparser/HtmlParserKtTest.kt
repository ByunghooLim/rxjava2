package com.example.hoo.mobilitytest.htmlparser

import com.example.hoo.mobilitytest.network.getStringResponse
import org.junit.Test

class HtmlParserKtTest {
    @Test
    fun getImageList() {
        getStringResponse()
                .test()
                .assertNoErrors()
                .assertValue {
                    val result = it.getImageList()
                    result.size == 549
                }
    }
}