package com.example.hoo.mobilitytest.view.main.contract

import android.os.Bundle
import android.support.v7.widget.RecyclerView
import com.example.hoo.mobilitytest.base.BasePresenter

sealed class MainContract {
    interface View {
        var mainAdapter : RecyclerView.Adapter<*>?
        fun showErrToast(msg: String)
    }

    interface Presenter : BasePresenter {
        fun initFromNetwork()
        fun initFromSavedInstance(savedInstanceState: Bundle)
        fun onSaveData(outState: Bundle?)
        fun cancelNetwork()
    }
}