package com.example.hoo.mobilitytest.glide

import android.content.Context
import com.bumptech.glide.Glide
import com.bumptech.glide.Registry
import com.bumptech.glide.annotation.GlideModule
import com.bumptech.glide.integration.okhttp3.OkHttpUrlLoader
import com.bumptech.glide.load.model.GlideUrl
import com.bumptech.glide.module.LibraryGlideModule
import com.example.hoo.mobilitytest.network.defaultHttpClient
import java.io.InputStream

@GlideModule
class OkHttp3Config : LibraryGlideModule() {
    override fun registerComponents(context: Context, glide: Glide, registry: Registry) {
        registry.setOkHttp3()
    }

    private fun Registry.setOkHttp3() {
        this.replace(GlideUrl::class.java, InputStream::class.java, OkHttpUrlLoader.Factory(defaultHttpClient))
    }
}
