package com.example.hoo.mobilitytest

enum class Extras {
    IMAGE_DATA,

    SAVED_IMAGE_DATA,
    RECYCLER_VIEW_POSITION,
}