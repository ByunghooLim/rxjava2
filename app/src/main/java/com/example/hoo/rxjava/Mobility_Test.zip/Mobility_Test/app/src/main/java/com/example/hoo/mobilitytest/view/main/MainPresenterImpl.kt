package com.example.hoo.mobilitytest.view.main

import android.os.Bundle
import com.example.hoo.mobilitytest.Extras.SAVED_IMAGE_DATA
import com.example.hoo.mobilitytest.htmlparser.getImageList
import com.example.hoo.mobilitytest.model.ImageData
import com.example.hoo.mobilitytest.network.cancelRequest
import com.example.hoo.mobilitytest.network.getStringResponse
import com.example.hoo.mobilitytest.view.main.adapter.MainRecyclerViewAdapter
import com.example.hoo.mobilitytest.view.main.contract.MainContract
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.schedulers.Schedulers

class MainPresenterImpl(private val mainView: MainContract.View) : MainContract.Presenter {
    override fun initFromNetwork() {
        getStringResponse()
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe({
                    it.setImageList()
                }, {
                    it.printStackTrace()
                    if(it.message != "Canceled" )
                        mainView.showErrToast("Error on initialize")
                })
    }

    private fun String.setImageList() {
        getImageList().run {
            initAdapter()
        }
    }

    private fun MutableList<ImageData>.initAdapter() {
        mainView.mainAdapter = MainRecyclerViewAdapter(this)
    }

    override fun initFromSavedInstance(savedInstanceState: Bundle) {
        val savedData = savedInstanceState.getParcelableArrayList<ImageData>(SAVED_IMAGE_DATA.toString()) ?: ArrayList()

        when {
            savedData.isEmpty() -> initFromNetwork()
            else -> {
                savedData.initAdapter()
            }
        }
    }

    override fun onSaveData(outState: Bundle?) {
        (mainView.mainAdapter as? MainRecyclerViewAdapter)?.let {
            outState?.putParcelableArrayList(SAVED_IMAGE_DATA.toString(), ArrayList(it.dataList))
        }
    }

    override fun cancelNetwork() {
        cancelRequest()
    }
}