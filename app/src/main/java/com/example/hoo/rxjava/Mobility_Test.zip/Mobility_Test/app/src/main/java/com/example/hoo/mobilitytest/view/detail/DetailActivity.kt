package com.example.hoo.mobilitytest.view.detail

import android.os.Bundle
import com.example.hoo.mobility_test.R
import com.example.hoo.mobility_test.databinding.ActivityDetailBinding
import com.example.hoo.mobilitytest.Extras
import com.example.hoo.mobilitytest.base.DataBindingActivity
import com.example.hoo.mobilitytest.extensions.toGlideImg
import com.example.hoo.mobilitytest.model.ImageData

class DetailActivity : DataBindingActivity<ActivityDetailBinding>(R.layout.activity_detail) {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding.detailImg.toGlideImg {
            val imageUrl = intent.getParcelableExtra<ImageData>(Extras.IMAGE_DATA.toString())?.ImageUrl
                    ?: ""
            it.load(imageUrl)
        }
    }
}