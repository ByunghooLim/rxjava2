package com.example.hoo.mobilitytest.base

import android.databinding.DataBindingUtil
import android.databinding.ViewDataBinding
import android.os.Bundle
import android.support.annotation.CallSuper
import android.support.v7.app.AppCompatActivity

abstract class PresenterActivity<T : ViewDataBinding, P : BasePresenter>(layoutId: Int) : DataBindingActivity<T>(layoutId) {
    protected abstract var presenter: P
}

abstract class DataBindingActivity<T : ViewDataBinding>(private val layoutId: Int) : AppCompatActivity() {
    protected lateinit var binding: T

    @CallSuper
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = DataBindingUtil.setContentView(this, layoutId)
    }
}