package com.example.hoo.mobilitytest.network

import org.junit.Test
import java.util.concurrent.TimeUnit

class HttpClientKtTest {
    @Test
    fun getStringResponseTest() {
        val title = "Slim Aarons Collection | Getty Images Gallery"

        getStringResponse()
                .test()
                .assertNoErrors()
                .assertValue {
                    it.contains(title, true)
                }
    }

    @Test
    fun cancelRequestTest() {
        getStringResponse()
                .test()
                .awaitDone(3L, TimeUnit.SECONDS)

        cancelRequest()

        assert(defaultHttpClient
                .dispatcher()
                .queuedCalls().isEmpty())

        assert(defaultHttpClient
                .dispatcher()
                .runningCalls().isEmpty())
    }
}