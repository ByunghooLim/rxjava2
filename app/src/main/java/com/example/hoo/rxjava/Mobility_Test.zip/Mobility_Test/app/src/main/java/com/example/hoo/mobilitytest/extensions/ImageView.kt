package com.example.hoo.mobilitytest.extensions

import android.graphics.drawable.Drawable
import android.widget.ImageView
import com.example.hoo.mobilitytest.glide.GlideApp
import com.example.hoo.mobilitytest.glide.GlideRequest
import com.example.hoo.mobilitytest.glide.GlideRequests

inline fun ImageView.toGlideImg(params: (GlideRequests) -> GlideRequest<Drawable>) {
    GlideApp.with(context).apply {
        params(this).into(this@toGlideImg)
    }
}