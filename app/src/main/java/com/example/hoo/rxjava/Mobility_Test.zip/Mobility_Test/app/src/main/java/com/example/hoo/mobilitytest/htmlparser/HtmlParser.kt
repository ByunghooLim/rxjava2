package com.example.hoo.mobilitytest.htmlparser

import com.example.hoo.mobilitytest.model.ImageData
import java.util.regex.Pattern

private const val IMG_TAG_PATTERN = "<img[^>]*src=[\\\\\\\"']([^\\\\\\\"^']*)"
private const val URL_DOMAIN = "http://www.gettyimagesgallery.com"

fun String.getImageList(): MutableList<ImageData> {
    return Pattern.compile(IMG_TAG_PATTERN)
            .matcher(this)
            .run {
                val result = ArrayList<ImageData>()
                while (find()) {
                    result.add(ImageData(URL_DOMAIN + group(1)))
                }
                result
            }
}
