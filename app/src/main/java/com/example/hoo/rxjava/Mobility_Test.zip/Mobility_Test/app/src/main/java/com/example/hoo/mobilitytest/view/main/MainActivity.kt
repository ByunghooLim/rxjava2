package com.example.hoo.mobilitytest.view.main

import android.os.Bundle
import android.support.v7.widget.GridLayoutManager
import android.support.v7.widget.RecyclerView
import android.widget.Toast
import com.example.hoo.mobility_test.R
import com.example.hoo.mobility_test.databinding.ActivityMainBinding
import com.example.hoo.mobilitytest.Extras.RECYCLER_VIEW_POSITION
import com.example.hoo.mobilitytest.base.PresenterActivity
import com.example.hoo.mobilitytest.view.main.contract.MainContract

class MainActivity : PresenterActivity<ActivityMainBinding, MainContract.Presenter>(R.layout.activity_main), MainContract.View {
    override var presenter: MainContract.Presenter = MainPresenterImpl(this)

    override var mainAdapter : RecyclerView.Adapter<*>?
        get() = binding.recyclerView.adapter
        set(value) {
            binding.recyclerView.adapter = value
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        initRecyclerView()

        when (savedInstanceState) {
            null -> presenter.initFromNetwork()
            else -> {
                presenter.initFromSavedInstance(savedInstanceState)
                binding.recyclerView.layoutManager?.onRestoreInstanceState(savedInstanceState.getParcelable(RECYCLER_VIEW_POSITION.toString()))
            }
        }
    }

    private fun initRecyclerView() {
        (binding.recyclerView.layoutManager as GridLayoutManager).spanCount = 2
    }

    override fun showErrToast(msg: String) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
    }

    override fun onSaveInstanceState(outState: Bundle?) {
        super.onSaveInstanceState(outState)

        outState?.putParcelable(RECYCLER_VIEW_POSITION.toString(), binding.recyclerView.layoutManager?.onSaveInstanceState())
        presenter.onSaveData(outState)
    }

    override fun onDestroy() {
        presenter.cancelNetwork()
        super.onDestroy()
    }
}